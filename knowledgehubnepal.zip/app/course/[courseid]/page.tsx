"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import {
  ChevronLeft,
  ChevronRight,
  Play,
  Pause,
  CheckCircle,
  Clock,
  BookOpen,
  User,
  Star,
  Download,
  FileText,
  MessageSquare,
  Bookmark,
  Share2,
  Volume2,
  Settings,
  Maximize,
  SkipBack,
  SkipForward,
} from "lucide-react"
import { YoutubePlayer } from "@/components/youtube-player"

interface VideoLesson {
  id: string
  title: string
  videoUrl: string
  duration: number
  description?: string
  resources?: Array<{
    title: string
    url: string
    type: string
  }>
}

interface Course {
  id: string
  title: string
  description: string
  instructor: string
  thumbnail: string
  videoLessons: VideoLesson[]
  totalDuration: number
  completedLessons: string[]
  currentLesson: number
}

export default function CoursePlayerPage() {
  const params = useParams()
  const courseid = params.courseid as string

  const [course, setCourse] = useState<Course | null>(null)
  const [currentLessonIndex, setCurrentLessonIndex] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)
  const [notes, setNotes] = useState("")
  const [isLoading, setIsLoading] = useState(true)

  // Mock data - replace with actual API call
  useEffect(() => {
    const fetchCourse = async () => {
      // Simulate API call
      setTimeout(() => {
        const mockCourse: Course = {
          id: courseid,
          title: "Digital Marketing Mastery",
          description:
            "Master digital marketing strategies, SEO, social media, and analytics to grow your business online.",
          instructor: "Rajesh Sharma",
          thumbnail: "/placeholder.svg?height=200&width=300",
          totalDuration: 1200, // 20 hours in minutes
          completedLessons: ["1", "2"],
          currentLesson: 2,
          videoLessons: [
            {
              id: "1",
              title: "Introduction to Digital Marketing",
              videoUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
              duration: 15,
              description:
                "Welcome to the Digital Marketing Mastery course. In this introductory lesson, we'll cover the fundamentals of digital marketing and what you can expect to learn throughout this comprehensive course.",
              resources: [
                { title: "Course Outline PDF", url: "#", type: "PDF" },
                { title: "Digital Marketing Checklist", url: "#", type: "PDF" },
              ],
            },
            {
              id: "2",
              title: "Understanding Your Target Audience",
              videoUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
              duration: 25,
              description:
                "Learn how to identify and understand your target audience. We'll explore customer personas, market research techniques, and how to create content that resonates with your ideal customers.",
              resources: [
                { title: "Customer Persona Template", url: "#", type: "Excel" },
                { title: "Market Research Guide", url: "#", type: "PDF" },
              ],
            },
            {
              id: "3",
              title: "SEO Fundamentals",
              videoUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
              duration: 35,
              description:
                "Dive deep into Search Engine Optimization. Learn keyword research, on-page optimization, technical SEO, and how to improve your website's visibility in search results.",
              resources: [
                { title: "SEO Checklist", url: "#", type: "PDF" },
                { title: "Keyword Research Tools", url: "#", type: "Link" },
              ],
            },
            {
              id: "4",
              title: "Content Marketing Strategy",
              videoUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
              duration: 30,
              description:
                "Create compelling content that drives engagement and conversions. Learn about content planning, creation, distribution, and measuring content performance.",
              resources: [
                { title: "Content Calendar Template", url: "#", type: "Excel" },
                { title: "Content Ideas Generator", url: "#", type: "PDF" },
              ],
            },
            {
              id: "5",
              title: "Social Media Marketing",
              videoUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
              duration: 40,
              description:
                "Master social media marketing across different platforms. Learn platform-specific strategies, content creation, community management, and social media advertising.",
              resources: [
                { title: "Social Media Templates", url: "#", type: "ZIP" },
                { title: "Platform Best Practices", url: "#", type: "PDF" },
              ],
            },
          ],
        }
        setCourse(mockCourse)
        setCurrentLessonIndex(mockCourse.currentLesson)
        setIsLoading(false)
      }, 1000)
    }

    fetchCourse()
  }, [courseid])

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading course...</p>
        </div>
      </div>
    )
  }

  if (!course) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Course not found</h1>
          <p className="text-gray-600 mb-4">The course you're looking for doesn't exist.</p>
          <Button asChild>
            <Link href="/dashboard/my-courses">Back to My Courses</Link>
          </Button>
        </div>
      </div>
    )
  }

  const currentLesson = course.videoLessons[currentLessonIndex]
  const progress = (course.completedLessons.length / course.videoLessons.length) * 100
  const isLessonCompleted = course.completedLessons.includes(currentLesson.id)

  const goToNextLesson = () => {
    if (currentLessonIndex < course.videoLessons.length - 1) {
      setCurrentLessonIndex(currentLessonIndex + 1)
    }
  }

  const goToPreviousLesson = () => {
    if (currentLessonIndex > 0) {
      setCurrentLessonIndex(currentLessonIndex - 1)
    }
  }

  const markLessonComplete = () => {
    if (!isLessonCompleted) {
      setCourse((prev) =>
        prev
          ? {
              ...prev,
              completedLessons: [...prev.completedLessons, currentLesson.id],
            }
          : null,
      )
    }
  }

  const getYoutubeId = (url: string) => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/
    const match = url.match(regExp)
    return match && match[2].length === 11 ? match[2] : null
  }

  const videoId = getYoutubeId(currentLesson.videoUrl)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" asChild>
                <Link href="/dashboard/my-courses">
                  <ChevronLeft className="h-4 w-4 mr-1" />
                  Back to Courses
                </Link>
              </Button>
              <Separator orientation="vertical" className="h-6" />
              <div>
                <h1 className="text-lg font-semibold text-gray-900">{course.title}</h1>
                <p className="text-sm text-gray-500">by {course.instructor}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="text-sm text-gray-600">Progress: {Math.round(progress)}%</div>
              <Progress value={progress} className="w-24" />
              <Button variant="outline" size="sm">
                <Share2 className="h-4 w-4 mr-1" />
                Share
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Video Player */}
            <Card className="overflow-hidden">
              <div className="aspect-video bg-black relative">
                {videoId ? (
                  <YoutubePlayer videoId={videoId} onEnd={markLessonComplete} />
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <p className="text-white">Video not available</p>
                  </div>
                )}
              </div>

              {/* Video Controls */}
              <div className="p-4 bg-gray-900 text-white">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={goToPreviousLesson}
                      disabled={currentLessonIndex === 0}
                      className="text-white hover:bg-gray-800"
                    >
                      <SkipBack className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setIsPlaying(!isPlaying)}
                      className="text-white hover:bg-gray-800"
                    >
                      {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={goToNextLesson}
                      disabled={currentLessonIndex === course.videoLessons.length - 1}
                      className="text-white hover:bg-gray-800"
                    >
                      <SkipForward className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm">
                      {currentLessonIndex + 1} / {course.videoLessons.length}
                    </span>
                    <Button variant="ghost" size="sm" className="text-white hover:bg-gray-800">
                      <Volume2 className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm" className="text-white hover:bg-gray-800">
                      <Settings className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm" className="text-white hover:bg-gray-800">
                      <Maximize className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </Card>

            {/* Lesson Info */}
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-xl mb-2">{currentLesson.title}</CardTitle>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        {currentLesson.duration} minutes
                      </div>
                      <div className="flex items-center">
                        <User className="h-4 w-4 mr-1" />
                        {course.instructor}
                      </div>
                      {isLessonCompleted && (
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Completed
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      <Bookmark className="h-4 w-4" />
                    </Button>
                    {!isLessonCompleted && (
                      <Button onClick={markLessonComplete} size="sm">
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Mark Complete
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>
            </Card>

            {/* Lesson Content Tabs */}
            <Card>
              <Tabs defaultValue="overview" className="w-full">
                <div className="border-b border-gray-200">
                  <TabsList className="w-full justify-start bg-transparent h-auto p-0">
                    <TabsTrigger
                      value="overview"
                      className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-transparent px-6 py-3"
                    >
                      Overview
                    </TabsTrigger>
                    <TabsTrigger
                      value="resources"
                      className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-transparent px-6 py-3"
                    >
                      Resources
                    </TabsTrigger>
                    <TabsTrigger
                      value="notes"
                      className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-transparent px-6 py-3"
                    >
                      Notes
                    </TabsTrigger>
                    <TabsTrigger
                      value="discussion"
                      className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-transparent px-6 py-3"
                    >
                      Discussion
                    </TabsTrigger>
                  </TabsList>
                </div>

                <TabsContent value="overview" className="p-6">
                  <div className="prose max-w-none">
                    <h3 className="text-lg font-semibold mb-3">About this lesson</h3>
                    <p className="text-gray-700 leading-relaxed">{currentLesson.description}</p>
                  </div>
                </TabsContent>

                <TabsContent value="resources" className="p-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Lesson Resources</h3>
                    {currentLesson.resources && currentLesson.resources.length > 0 ? (
                      <div className="space-y-3">
                        {currentLesson.resources.map((resource, index) => (
                          <div
                            key={index}
                            className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50"
                          >
                            <div className="flex items-center space-x-3">
                              <FileText className="h-5 w-5 text-blue-600" />
                              <div>
                                <p className="font-medium">{resource.title}</p>
                                <p className="text-sm text-gray-500">{resource.type}</p>
                              </div>
                            </div>
                            <Button variant="outline" size="sm" asChild>
                              <a href={resource.url} target="_blank" rel="noopener noreferrer">
                                <Download className="h-4 w-4 mr-1" />
                                Download
                              </a>
                            </Button>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500">No resources available for this lesson.</p>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="notes" className="p-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Your Notes</h3>
                    <Textarea
                      placeholder="Take notes about this lesson..."
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      className="min-h-[200px]"
                    />
                    <Button>Save Notes</Button>
                  </div>
                </TabsContent>

                <TabsContent value="discussion" className="p-6">
                  <div className="text-center py-8">
                    <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Join the Discussion</h3>
                    <p className="text-gray-600 mb-4">Ask questions and discuss this lesson with other students.</p>
                    <Button>Start Discussion</Button>
                  </div>
                </TabsContent>
              </Tabs>
            </Card>

            {/* Navigation */}
            <div className="flex justify-between">
              <Button variant="outline" onClick={goToPreviousLesson} disabled={currentLessonIndex === 0}>
                <ChevronLeft className="h-4 w-4 mr-1" />
                Previous Lesson
              </Button>
              <Button onClick={goToNextLesson} disabled={currentLessonIndex === course.videoLessons.length - 1}>
                Next Lesson
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 space-y-6">
              {/* Course Progress */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Course Progress</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Overall Progress</span>
                      <span>{Math.round(progress)}%</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>
                  <div className="text-sm text-gray-600">
                    <span className="font-medium">{course.completedLessons.length}</span> of{" "}
                    <span className="font-medium">{course.videoLessons.length}</span> lessons completed
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>{Math.floor(course.totalDuration / 60)} hours total</span>
                  </div>
                </CardContent>
              </Card>

              {/* Course Content */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Course Content</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="max-h-96 overflow-y-auto">
                    {course.videoLessons.map((lesson, index) => {
                      const isActive = index === currentLessonIndex
                      const isCompleted = course.completedLessons.includes(lesson.id)

                      return (
                        <button
                          key={lesson.id}
                          onClick={() => setCurrentLessonIndex(index)}
                          className={`w-full text-left p-4 border-b border-gray-100 hover:bg-gray-50 transition-colors ${
                            isActive ? "bg-blue-50 border-l-4 border-l-blue-600" : ""
                          }`}
                        >
                          <div className="flex items-start space-x-3">
                            <div className="flex-shrink-0 mt-1">
                              {isCompleted ? (
                                <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                                  <CheckCircle className="h-4 w-4 text-white" />
                                </div>
                              ) : isActive ? (
                                <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                                  <Play className="h-3 w-3 text-white" />
                                </div>
                              ) : (
                                <div className="w-6 h-6 border-2 border-gray-300 rounded-full flex items-center justify-center">
                                  <span className="text-xs font-medium text-gray-600">{index + 1}</span>
                                </div>
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p
                                className={`text-sm font-medium truncate ${isActive ? "text-blue-900" : "text-gray-900"}`}
                              >
                                {lesson.title}
                              </p>
                              <div className="flex items-center mt-1 text-xs text-gray-500">
                                <Clock className="h-3 w-3 mr-1" />
                                <span>{lesson.duration} min</span>
                              </div>
                            </div>
                          </div>
                        </button>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* Course Info */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">About This Course</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center text-sm">
                    <User className="h-4 w-4 mr-2 text-gray-500" />
                    <span>Instructor: {course.instructor}</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <BookOpen className="h-4 w-4 mr-2 text-gray-500" />
                    <span>{course.videoLessons.length} Lessons</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <Clock className="h-4 w-4 mr-2 text-gray-500" />
                    <span>{Math.floor(course.totalDuration / 60)} Hours</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between">
                    <Button variant="ghost" size="sm">
                      <Star className="h-4 w-4 mr-1" />
                      Rate
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Download className="h-4 w-4 mr-1" />
                      Certificate
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
