"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface LeaderboardEntry {
  rank: number
  id: string
  name: string
  username: string
  image?: string
  email: string
  earnings?: number
  sales?: number
  referrals?: number
}

export default function LeaderboardPage() {
  const [earningsLeaderboard, setEarningsLeaderboard] = useState<LeaderboardEntry[]>([])
  const [referralsLeaderboard, setReferralsLeaderboard] = useState<LeaderboardEntry[]>([])
  const [monthlyLeaderboard, setMonthlyLeaderboard] = useState<LeaderboardEntry[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchLeaderboardData()
  }, [])

  const fetchLeaderboardData = async () => {
    try {
      setLoading(true)

      // Fetch earnings leaderboard
      const earningsResponse = await fetch("/api/leaderboard/earnings?limit=10")
      if (earningsResponse.ok) {
        const earningsData = await earningsResponse.json()
        setEarningsLeaderboard(earningsData.leaderboard)
      }

      // Fetch referrals leaderboard
      const referralsResponse = await fetch("/api/leaderboard/referrals?limit=10")
      if (referralsResponse.ok) {
        const referralsData = await referralsResponse.json()
        setReferralsLeaderboard(referralsData.leaderboard)
      }

      // Fetch monthly leaderboard
      const monthlyResponse = await fetch("/api/leaderboard/monthly?limit=5")
      if (monthlyResponse.ok) {
        const monthlyData = await monthlyResponse.json()
        setMonthlyLeaderboard(monthlyData.leaderboard)
      }
    } catch (error) {
      console.error("Error fetching leaderboard data:", error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex-1 space-y-4 p-4 pt-6 md:p-8">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold tracking-tight">Affiliate Leaderboard</h2>
        </div>
        <div className="animate-pulse">
          <div className="h-10 bg-gray-200 rounded mb-8"></div>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-16 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex-1 space-y-4 p-4 pt-6 md:p-8">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Affiliate Leaderboard</h2>
      </div>

      <Tabs defaultValue="earnings" className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-8">
          <TabsTrigger value="earnings">Top Earners</TabsTrigger>
          <TabsTrigger value="referrals">Most Referrals</TabsTrigger>
          <TabsTrigger value="monthly">Monthly Champions</TabsTrigger>
        </TabsList>

        <TabsContent value="earnings">
          <Card>
            <CardHeader>
              <CardTitle>Top Affiliate Earners</CardTitle>
              <CardDescription>Affiliates who have earned the most commission</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <div className="grid grid-cols-12 gap-4 p-4 font-medium">
                  <div className="col-span-1">Rank</div>
                  <div className="col-span-3">Affiliate</div>
                  <div className="col-span-3">Username</div>
                  <div className="col-span-2">Sales</div>
                  <div className="col-span-3">Total Earnings</div>
                </div>

                {earningsLeaderboard.map((affiliate) => (
                  <div key={affiliate.id} className="grid grid-cols-12 gap-4 border-t p-4 items-center">
                    <div className="col-span-1">
                      <Badge
                        variant={affiliate.rank <= 3 ? "default" : "outline"}
                        className="w-8 h-8 rounded-full flex items-center justify-center p-0"
                      >
                        {affiliate.rank}
                      </Badge>
                    </div>
                    <div className="col-span-3 flex items-center gap-2">
                      <Avatar className="h-8 w-8">
                        <AvatarImage
                          src={affiliate.image || `/placeholder.svg?height=32&width=32`}
                          alt={affiliate.name}
                        />
                        <AvatarFallback>{affiliate.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <span className="font-medium truncate">{affiliate.name}</span>
                    </div>
                    <div className="col-span-3 text-muted-foreground">@{affiliate.username}</div>
                    <div className="col-span-2">{affiliate.sales} sales</div>
                    <div className="col-span-3 font-semibold">Rs. {affiliate.earnings?.toLocaleString()}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="referrals">
          <Card>
            <CardHeader>
              <CardTitle>Most Referrals</CardTitle>
              <CardDescription>Affiliates who have referred the most users</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <div className="grid grid-cols-12 gap-4 p-4 font-medium">
                  <div className="col-span-1">Rank</div>
                  <div className="col-span-3">Affiliate</div>
                  <div className="col-span-3">Username</div>
                  <div className="col-span-5">Total Referrals</div>
                </div>

                {referralsLeaderboard.map((affiliate) => (
                  <div key={affiliate.id} className="grid grid-cols-12 gap-4 border-t p-4 items-center">
                    <div className="col-span-1">
                      <Badge
                        variant={affiliate.rank <= 3 ? "default" : "outline"}
                        className="w-8 h-8 rounded-full flex items-center justify-center p-0"
                      >
                        {affiliate.rank}
                      </Badge>
                    </div>
                    <div className="col-span-3 flex items-center gap-2">
                      <Avatar className="h-8 w-8">
                        <AvatarImage
                          src={affiliate.image || `/placeholder.svg?height=32&width=32`}
                          alt={affiliate.name}
                        />
                        <AvatarFallback>{affiliate.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <span className="font-medium truncate">{affiliate.name}</span>
                    </div>
                    <div className="col-span-3 text-muted-foreground">@{affiliate.username}</div>
                    <div className="col-span-5">
                      <div className="flex items-center gap-2">
                        <div className="h-2 bg-primary/20 rounded-full w-full max-w-xs">
                          <div
                            className="h-full bg-primary rounded-full"
                            style={{
                              width: `${Math.min(100, (affiliate.referrals! / (referralsLeaderboard[0]?.referrals || 1)) * 100)}%`,
                            }}
                          />
                        </div>
                        <span className="font-semibold">{affiliate.referrals}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="monthly">
          <Card>
            <CardHeader>
              <CardTitle>Monthly Champions</CardTitle>
              <CardDescription>Top performers for the current month</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                {monthlyLeaderboard.map((affiliate) => (
                  <Card key={affiliate.id} className={affiliate.rank === 1 ? "border-primary" : ""}>
                    <CardContent className="pt-6">
                      <div className="text-center mb-4">
                        <Badge
                          variant={affiliate.rank <= 3 ? "default" : "outline"}
                          className="w-8 h-8 rounded-full flex items-center justify-center mx-auto mb-4"
                        >
                          {affiliate.rank}
                        </Badge>
                        <Avatar className="h-16 w-16 mx-auto mb-2">
                          <AvatarImage
                            src={affiliate.image || `/placeholder.svg?height=64&width=64`}
                            alt={affiliate.name}
                          />
                          <AvatarFallback>{affiliate.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <h3 className="font-semibold text-lg">{affiliate.name}</h3>
                        <p className="text-muted-foreground text-sm">@{affiliate.username}</p>
                      </div>

                      <div className="space-y-2 text-center">
                        <div>
                          <p className="text-muted-foreground text-xs">Earnings</p>
                          <p className="font-bold text-xl">Rs. {affiliate.earnings?.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground text-xs">Sales</p>
                          <p className="font-medium">{affiliate.sales}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
