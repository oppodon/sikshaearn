"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, CreditCard, Info } from "lucide-react"
import Link from "next/link"

export default function WithdrawalPage() {
  const [amount, setAmount] = useState("5000")
  const [paymentMethod, setPaymentMethod] = useState("bank")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
      // Redirect or show success message
    }, 1500)
  }

  return (
    <div className="p-6">
      <div className="mb-8 flex items-center gap-2">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/dashboard/payouts">
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">Back</span>
          </Link>
        </Button>
        <h1 className="text-2xl font-bold">Request Withdrawal</h1>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-2">
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-0 pt-6">
              <CardTitle className="text-xl font-bold">Withdrawal Details</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="amount">Withdrawal Amount (Rs.)</Label>
                  <Input
                    id="amount"
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    min="1000"
                    max="12450"
                    required
                  />
                  <p className="text-sm text-gray-500">Minimum withdrawal: Rs. 1,000</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="payment-method">Payment Method</Label>
                  <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                    <SelectTrigger id="payment-method">
                      <SelectValue placeholder="Select payment method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bank">Bank Transfer (Nepal Investment Bank)</SelectItem>
                      <SelectItem value="esewa">eSewa</SelectItem>
                      <SelectItem value="khalti">Khalti</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {paymentMethod === "bank" && (
                  <div className="rounded-lg bg-blue-50 p-4">
                    <div className="flex items-start gap-3">
                      <Info className="mt-0.5 h-5 w-5 text-blue-600" />
                      <div>
                        <h3 className="font-medium text-blue-800">Bank Transfer Information</h3>
                        <p className="text-sm text-blue-700">
                          Your funds will be transferred to your registered bank account (Nepal Investment Bank
                          ****6789). Transfers typically take 2-3 business days to process.
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                <div className="rounded-lg bg-gray-50 p-4">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Processing Fee (2%)</span>
                    <span>Rs. {(Number(amount) * 0.02).toFixed(2)}</span>
                  </div>
                  <div className="mt-2 flex items-center justify-between">
                    <span className="font-medium">You will receive</span>
                    <span className="text-lg font-bold">Rs. {(Number(amount) * 0.98).toFixed(2)}</span>
                  </div>
                </div>

                <Button type="submit" className="w-full" disabled={isSubmitting}>
                  {isSubmitting ? "Processing..." : "Request Withdrawal"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-0 pt-6">
              <CardTitle className="text-xl font-bold">Withdrawal Summary</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div>
                  <div className="text-sm font-medium text-gray-500">Available Balance</div>
                  <div className="text-2xl font-bold">Rs. 12,450</div>
                </div>

                <div className="rounded-lg bg-gray-50 p-4">
                  <div className="flex items-center gap-3">
                    <div className="rounded-full bg-blue-50 p-2">
                      <CreditCard className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">Bank Transfer</h3>
                      <p className="text-sm text-gray-500">Nepal Investment Bank ****6789</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="font-medium">Recent Withdrawals</h3>
                  {recentWithdrawals.length > 0 ? (
                    <div className="space-y-3">
                      {recentWithdrawals.map((withdrawal, i) => (
                        <div key={i} className="rounded-lg border p-3">
                          <div className="flex items-center justify-between">
                            <span className="font-medium">Rs. {withdrawal.amount}</span>
                            <span
                              className={`text-sm ${
                                withdrawal.status === "Completed"
                                  ? "text-green-600"
                                  : withdrawal.status === "Processing"
                                    ? "text-yellow-600"
                                    : "text-gray-500"
                              }`}
                            >
                              {withdrawal.status}
                            </span>
                          </div>
                          <div className="text-sm text-gray-500">{withdrawal.date}</div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500">No recent withdrawals</p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

const recentWithdrawals = [
  {
    amount: 5000,
    date: "May 10, 2025",
    status: "Completed",
  },
  {
    amount: 3000,
    date: "April 15, 2025",
    status: "Completed",
  },
  {
    amount: 7500,
    date: "March 22, 2025",
    status: "Completed",
  },
]
