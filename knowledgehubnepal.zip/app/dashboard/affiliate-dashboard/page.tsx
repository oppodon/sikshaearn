"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Copy, ExternalLink } from "lucide-react"
import Link from "next/link"
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { AffiliateStats } from "@/components/affiliate-stats"
import { AffiliateChart } from "@/components/affiliate-chart"
import { toast } from "sonner"

interface AffiliateStatsData {
  totalEarnings: number
  availableBalance: number
  totalReferrals: number
  conversionRate: string
  referralLink: string
  referralCode: string
}

interface Commission {
  id: string
  date: string
  product: string
  customer: string
  amount: number
  status: string
}

interface TopProduct {
  id: string
  name: string
  sales: number
  commission: number
}

export default function AffiliateDashboardPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [stats, setStats] = useState<AffiliateStatsData | null>(null)
  const [commissions, setCommissions] = useState<Commission[]>([])
  const [topProducts, setTopProducts] = useState<TopProduct[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/login?callbackUrl=/dashboard/affiliate-dashboard")
      return
    }

    if (status === "authenticated") {
      fetchAffiliateData()
    }
  }, [status, router])

  const fetchAffiliateData = async () => {
    try {
      setLoading(true)

      // Fetch affiliate stats
      const statsResponse = await fetch("/api/affiliate/stats")
      if (statsResponse.ok) {
        const statsData = await statsResponse.json()
        setStats(statsData.data)
      }

      // Fetch recent commissions
      const commissionsResponse = await fetch("/api/affiliate/commissions?limit=5")
      if (commissionsResponse.ok) {
        const commissionsData = await commissionsResponse.json()
        setCommissions(commissionsData.commissions)
      }

      // Fetch top products
      const productsResponse = await fetch("/api/affiliate/top-products?limit=4")
      if (productsResponse.ok) {
        const productsData = await productsResponse.json()
        setTopProducts(productsData.products)
      }
    } catch (error) {
      console.error("Error fetching affiliate data:", error)
      toast.error("Failed to load affiliate data")
    } finally {
      setLoading(false)
    }
  }

  const copyReferralLink = () => {
    if (stats?.referralLink) {
      navigator.clipboard.writeText(stats.referralLink)
      toast.success("Referral link copied to clipboard!")
    }
  }

  if (status === "loading" || loading) {
    return (
      <div className="flex-1 space-y-4 p-4 pt-6 md:p-8">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold tracking-tight">Affiliate Dashboard</h2>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-8 bg-gray-200 rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  if (!stats) {
    return (
      <div className="flex-1 space-y-4 p-4 pt-6 md:p-8">
        <div className="text-center">
          <p>Failed to load affiliate data. Please try again.</p>
          <Button onClick={fetchAffiliateData} className="mt-4">
            Retry
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="flex-1 space-y-4 p-4 pt-6 md:p-8">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Affiliate Dashboard</h2>
        <div className="flex items-center gap-2">
          <Button variant="outline">Last 30 days</Button>
        </div>
      </div>

      <AffiliateStats
        totalEarnings={stats.totalEarnings}
        availableBalance={stats.availableBalance}
        totalReferrals={stats.totalReferrals}
        conversionRate={stats.conversionRate}
      />

      <Card>
        <CardHeader>
          <CardTitle>Your Affiliate Link</CardTitle>
          <CardDescription>Share this link to earn commissions on referrals</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="flex-1 flex items-center gap-2 p-2 border rounded-md bg-muted/50">
              <span className="text-sm truncate">{stats.referralLink}</span>
              <Button variant="ghost" size="icon" className="ml-auto flex-shrink-0" onClick={copyReferralLink}>
                <Copy className="h-4 w-4" />
                <span className="sr-only">Copy</span>
              </Button>
            </div>
            <Button className="flex-shrink-0" asChild>
              <Link href="/dashboard/affiliate-link">
                Manage Links
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Earnings Overview</CardTitle>
            <CardDescription>Your earnings over the past year</CardDescription>
          </CardHeader>
          <CardContent className="pl-2">
            <AffiliateChart />
          </CardContent>
        </Card>

        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Top Performing Products</CardTitle>
            <CardDescription>Products generating the most commissions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topProducts.map((product, i) => (
                <div key={i} className="flex items-center gap-4">
                  <div className="flex-1 space-y-1">
                    <p className="text-sm font-medium leading-none">{product.name}</p>
                    <div className="flex items-center text-sm">
                      <span className="text-muted-foreground">{product.sales} sales</span>
                      <span className="mx-2 text-muted-foreground">•</span>
                      <span className="font-medium">Rs. {product.commission}</span>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" asChild>
                    <Link href={`/dashboard/affiliate-link?product=${product.id}`}>
                      <ExternalLink className="mr-2 h-3 w-3" />
                      Promote
                    </Link>
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Commissions</CardTitle>
          <CardDescription>Your most recent affiliate earnings</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="rounded-md border">
              <div className="grid grid-cols-5 gap-4 p-4 font-medium">
                <div>Date</div>
                <div>Product</div>
                <div>Customer</div>
                <div>Amount</div>
                <div>Status</div>
              </div>
              {commissions.map((commission, i) => (
                <div key={i} className="grid grid-cols-5 gap-4 border-t p-4">
                  <div className="text-sm">{commission.date}</div>
                  <div className="text-sm font-medium">{commission.product}</div>
                  <div className="text-sm">{commission.customer}</div>
                  <div className="text-sm">Rs. {commission.amount}</div>
                  <div>
                    <Badge
                      variant="outline"
                      className={
                        commission.status === "Paid"
                          ? "bg-green-50 text-green-700 border-green-200"
                          : commission.status === "Pending"
                            ? "bg-yellow-50 text-yellow-700 border-yellow-200"
                            : "bg-blue-50 text-blue-700 border-blue-200"
                      }
                    >
                      {commission.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex justify-end">
              <Button variant="outline" asChild>
                <Link href="/dashboard/payouts">
                  View All Transactions
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
