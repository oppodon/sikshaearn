import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { BookOpen, Clock, Play, Search, Filter, Award, Package } from "lucide-react"
import { Suspense } from "react"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"

async function getEnrolledCourses(userId: string) {
  try {
    const response = await fetch(`${process.env.NEXTAUTH_URL}/api/courses/enrolled`, {
      cache: "no-store",
    })

    if (!response.ok) {
      throw new Error("Failed to fetch enrolled courses")
    }

    const data = await response.json()
    return data.courses || []
  } catch (error) {
    console.error("Error fetching enrolled courses:", error)
    return []
  }
}

export default async function MyCoursesPage() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect("/login")
  }

  const enrolledCourses = await getEnrolledCourses(session.user.id)

  // Filter courses by progress status
  const notStartedCourses = enrolledCourses.filter((course: any) => course.progress === 0)
  const inProgressCourses = enrolledCourses.filter((course: any) => course.progress > 0 && course.progress < 100)
  const completedCourses = enrolledCourses.filter((course: any) => course.progress === 100)

  return (
    <div className="w-full space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-2xl font-bold tracking-tight md:text-3xl">My Courses</h1>
        <p className="text-muted-foreground">Track your learning progress and continue where you left off</p>
      </div>

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Search your courses..." className="pl-10" />
        </div>
        <Select>
          <SelectTrigger className="w-full sm:w-[180px]">
            <Filter className="mr-2 h-4 w-4" />
            <SelectValue placeholder="Filter by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Courses</SelectItem>
            <SelectItem value="in-progress">In Progress</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="not-started">Not Started</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="enrolled" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="enrolled" className="flex items-center gap-2">
            <BookOpen className="h-4 w-4" />
            Enrolled ({notStartedCourses.length})
          </TabsTrigger>
          <TabsTrigger value="active" className="flex items-center gap-2">
            <Play className="h-4 w-4" />
            Active ({inProgressCourses.length})
          </TabsTrigger>
          <TabsTrigger value="completed" className="flex items-center gap-2">
            <Award className="h-4 w-4" />
            Completed ({completedCourses.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="enrolled" className="mt-6">
          <Suspense fallback={<p>Loading courses...</p>}>
            {notStartedCourses.length === 0 ? (
              <EmptyState
                title="No enrolled courses yet"
                description="Browse our catalog to find courses that interest you"
                actionLabel="Explore Courses"
                actionHref="/courses"
              />
            ) : (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {notStartedCourses.map((course: any) => (
                  <CourseCard key={course._id} course={course} />
                ))}
              </div>
            )}
          </Suspense>
        </TabsContent>

        <TabsContent value="active" className="mt-6">
          <Suspense fallback={<p>Loading courses...</p>}>
            {inProgressCourses.length === 0 ? (
              <EmptyState
                title="No active courses"
                description="Start learning to see your courses here"
                actionLabel="Explore Courses"
                actionHref="/courses"
              />
            ) : (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {inProgressCourses.map((course: any) => (
                  <CourseCard key={course._id} course={course} />
                ))}
              </div>
            )}
          </Suspense>
        </TabsContent>

        <TabsContent value="completed" className="mt-6">
          <Suspense fallback={<p>Loading courses...</p>}>
            {completedCourses.length === 0 ? (
              <EmptyState
                title="No completed courses yet"
                description="Keep learning to complete your courses"
                actionLabel="Continue Learning"
                actionHref="/courses"
              />
            ) : (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {completedCourses.map((course: any) => (
                  <CourseCard key={course._id} course={course} />
                ))}
              </div>
            )}
          </Suspense>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function CourseCard({ course }: { course: any }) {
  const getStatusBadge = () => {
    if (course.progress === 100) {
      return (
        <span className="absolute right-3 top-3 rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800">
          Completed
        </span>
      )
    } else if (course.progress > 0) {
      return (
        <span className="absolute right-3 top-3 rounded-full bg-blue-100 px-2.5 py-0.5 text-xs font-medium text-blue-800">
          In Progress
        </span>
      )
    } else {
      return (
        <span className="absolute right-3 top-3 rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-800">
          Not Started
        </span>
      )
    }
  }

  const getButtonText = () => {
    if (course.progress === 0) return "Start Learning"
    if (course.progress === 100) return "Review Course"
    return "Continue Learning"
  }

  // Calculate total duration from all video lessons
  const totalDuration =
    course.videoLessons?.reduce((total: number, lesson: any) => total + (lesson.duration || 0), 0) || 0
  const totalHours = Math.floor(totalDuration / 60)
  const totalMinutes = totalDuration % 60
  const formattedDuration =
    totalHours > 0
      ? `${totalHours} hr${totalHours > 1 ? "s" : ""} ${totalMinutes > 0 ? `${totalMinutes} min` : ""}`
      : `${totalMinutes} min`

  // Get total number of lessons
  const totalLessons = course.videoLessons?.length || 0

  return (
    <Card className="group overflow-hidden transition-all hover:shadow-md">
      <div className="relative aspect-video overflow-hidden">
        <img
          src={course.thumbnail || "/placeholder.svg?height=200&width=400"}
          alt={course.title}
          className="h-full w-full object-cover transition-transform group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-black/20 opacity-0 transition-opacity group-hover:opacity-100" />
        {getStatusBadge()}
      </div>
      <CardContent className="p-4">
        <div className="space-y-3">
          <h3 className="font-semibold text-lg leading-tight line-clamp-2">{course.title}</h3>

          {course.packageName && (
            <div className="flex items-center gap-1.5">
              <Package className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">{course.packageName}</span>
            </div>
          )}

          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              <span>{formattedDuration}</span>
            </div>
            <span>
              {course.completedLessons?.length || 0}/{totalLessons} lessons
            </span>
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between text-sm">
              <span className="font-medium">Progress</span>
              <span className="text-muted-foreground">{course.progress || 0}%</span>
            </div>
            <Progress value={course.progress || 0} className="h-2" />
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Button asChild className="w-full" size="sm">
          <Link href={`/course/${course._id}`}>
            <Play className="mr-2 h-4 w-4" />
            {getButtonText()}
          </Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

function EmptyState({
  title,
  description,
  actionLabel,
  actionHref,
}: {
  title: string
  description: string
  actionLabel: string
  actionHref: string
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-gray-300 py-12">
      <div className="mx-auto max-w-sm text-center">
        <BookOpen className="mx-auto h-12 w-12 text-gray-400" />
        <h3 className="mt-4 text-lg font-medium text-gray-900">{title}</h3>
        <p className="mt-2 text-sm text-gray-500">{description}</p>
        <Button asChild className="mt-6">
          <Link href={actionHref}>{actionLabel}</Link>
        </Button>
      </div>
    </div>
  )
}
