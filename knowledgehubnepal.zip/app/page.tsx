import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ModeToggle } from "@/components/mode-toggle"
import { LightbulbIcon, Award, Target } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { CheckCircle } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="border-b bg-white dark:bg-gray-950">
        <div className="container mx-auto flex h-16 items-center justify-between px-4 md:px-6">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center">
              <span className="text-xl font-bold text-blue-600">SikshaEarn</span>
            </Link>
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="/" className="text-sm font-medium text-blue-600 border-b-2 border-blue-600 py-2">
              HOME
            </Link>
            <Link
              href="/packages"
              className="text-sm font-medium text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50 py-2"
            >
              COURSE PACKAGE
            </Link>
            <Link
              href="/courses"
              className="text-sm font-medium text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50 py-2"
            >
              COURSES
            </Link>
            <Link
              href="/about"
              className="text-sm font-medium text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50 py-2"
            >
              ABOUT
            </Link>
            <Link
              href="/contact"
              className="text-sm font-medium text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50 py-2"
            >
              CONTACT US
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <ModeToggle />
            <Button variant="ghost" size="icon" className="rounded-full">
              <span className="bg-blue-100 text-blue-800 text-xs font-medium rounded-full px-2.5 py-1 dark:bg-blue-900 dark:text-blue-300">
                OMI
              </span>
              <span className="sr-only">User</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gray-50 py-12 md:py-24 dark:bg-gray-900">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-gray-900 dark:text-white mb-6">
            Elevate Your Digital Skills
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-3xl mx-auto mb-8">
            We provide comprehensive learning experiences designed to help you achieve your goals and advance your
            career in the digital world.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
              <Link href="/packages">Explore Packages</Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link href="/courses">Browse Courses</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid gap-8 md:grid-cols-3">
            {/* Feature 1 */}
            <div className="group relative overflow-hidden rounded-lg border bg-white shadow-sm transition-all hover:shadow-md dark:border-gray-800 dark:bg-gray-950">
              <div className="relative aspect-video overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-black/0 z-10"></div>
                <img
                  src="/placeholder.svg?height=400&width=600"
                  alt="Innovative Learning"
                  className="object-cover w-full h-full"
                />
                <div className="absolute top-4 left-4 z-20 bg-white p-2 rounded-md shadow-md dark:bg-gray-800">
                  <LightbulbIcon className="h-6 w-6 text-yellow-500" />
                </div>
                <h3 className="absolute bottom-4 left-4 text-2xl font-bold text-white z-20">Innovative Learning</h3>
              </div>
              <div className="p-6">
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  Our courses use cutting-edge teaching methods and technologies for effective learning.
                </p>
                <Link
                  href="/about#innovative"
                  className="inline-flex items-center text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                >
                  Learn more
                  <svg
                    className="ml-1 h-4 w-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </Link>
              </div>
            </div>

            {/* Feature 2 */}
            <div className="group relative overflow-hidden rounded-lg border bg-white shadow-sm transition-all hover:shadow-md dark:border-gray-800 dark:bg-gray-950">
              <div className="relative aspect-video overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-black/0 z-10"></div>
                <img
                  src="/placeholder.svg?height=400&width=600"
                  alt="Industry Recognized"
                  className="object-cover w-full h-full"
                />
                <div className="absolute top-4 left-4 z-20 bg-white p-2 rounded-md shadow-md dark:bg-gray-800">
                  <Award className="h-6 w-6 text-green-500" />
                </div>
                <h3 className="absolute bottom-4 left-4 text-2xl font-bold text-white z-20">Industry Recognized</h3>
              </div>
              <div className="p-6">
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  Earn certificates that are recognized and valued by employers across industries.
                </p>
                <Link
                  href="/about#recognized"
                  className="inline-flex items-center text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                >
                  Learn more
                  <svg
                    className="ml-1 h-4 w-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </Link>
              </div>
            </div>

            {/* Feature 3 */}
            <div className="group relative overflow-hidden rounded-lg border bg-white shadow-sm transition-all hover:shadow-md dark:border-gray-800 dark:bg-gray-950">
              <div className="relative aspect-video overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-black/0 z-10"></div>
                <img
                  src="/placeholder.svg?height=400&width=600"
                  alt="Career-Focused"
                  className="object-cover w-full h-full"
                />
                <div className="absolute top-4 left-4 z-20 bg-white p-2 rounded-md shadow-md dark:bg-gray-800">
                  <Target className="h-6 w-6 text-blue-500" />
                </div>
                <h3 className="absolute bottom-4 left-4 text-2xl font-bold text-white z-20">Career-Focused</h3>
              </div>
              <div className="p-6">
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  Our programs are designed to help you achieve specific career goals and advancement.
                </p>
                <Link
                  href="/about#career"
                  className="inline-flex items-center text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                >
                  Learn more
                  <svg
                    className="ml-1 h-4 w-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Packages Section */}
      <section className="bg-gray-50 py-16 md:py-24 dark:bg-gray-900">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Choose Your Learning Path</h2>
            <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Select from our range of carefully designed packages to accelerate your learning journey and achieve your
              career goals in digital marketing.
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {/* Silver Package */}
            <div className="rounded-lg border bg-white shadow-sm dark:border-gray-800 dark:bg-gray-950">
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Silver Package</h3>
                <div className="text-3xl font-bold mb-4">$99</div>
                <p className="text-gray-600 dark:text-gray-300 text-sm mb-6">
                  Perfect for beginners looking to start their digital marketing journey.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>5 Core Courses</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>Basic Support</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>3 Months Access</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>Certificate</span>
                  </li>
                </ul>
                <Button className="w-full" variant="outline">
                  Get Started
                </Button>
              </div>
            </div>

            {/* Gold Package */}
            <div className="rounded-lg border bg-white shadow-sm dark:border-gray-800 dark:bg-gray-950">
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Gold Package</h3>
                <div className="text-3xl font-bold mb-4">$199</div>
                <p className="text-gray-600 dark:text-gray-300 text-sm mb-6">
                  Ideal for those seeking to expand their digital marketing skills.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>10 Courses</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>Priority Support</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>6 Months Access</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>Certificate</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>1 Live Workshop</span>
                  </li>
                </ul>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">Get Started</Button>
              </div>
            </div>

            {/* Diamond Package */}
            <div className="rounded-lg border bg-blue-50 shadow-md relative dark:border-blue-900 dark:bg-blue-900/20">
              <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-blue-600">POPULAR</Badge>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Diamond Package</h3>
                <div className="text-3xl font-bold mb-4">$299</div>
                <p className="text-gray-600 dark:text-gray-300 text-sm mb-6">
                  Comprehensive package for serious digital marketing professionals.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>All Courses</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>24/7 Support</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>12 Months Access</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>Certificate</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>3 Live Workshops</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>1-on-1 Mentoring</span>
                  </li>
                </ul>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">Get Started</Button>
              </div>
            </div>

            {/* Heroic Package */}
            <div className="rounded-lg border bg-white shadow-sm dark:border-gray-800 dark:bg-gray-950">
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Heroic Package</h3>
                <div className="text-3xl font-bold mb-4">$499</div>
                <p className="text-gray-600 dark:text-gray-300 text-sm mb-6">
                  Ultimate package for those aiming to master digital marketing.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>All Courses</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>VIP Support</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>Lifetime Access</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>Certificate</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>Unlimited Workshops</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>Weekly Mentoring</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span>Job Placement Assistance</span>
                  </li>
                </ul>
                <Button className="w-full" variant="outline">
                  Get Started
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 py-16 md:py-24 text-white">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h2 className="text-3xl font-bold mb-6">Still Have Questions?</h2>
          <p className="text-blue-100 max-w-2xl mx-auto mb-8">
            Our team is ready to help you choose the right package for your learning goals. Contact us for personalized
            assistance.
          </p>
          <Button asChild size="lg" className="bg-white text-blue-600 hover:bg-blue-50">
            <Link href="/contact">Contact Us</Link>
          </Button>
        </div>
      </section>
    </div>
  )
}
