import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import dbConnect from "@/lib/mongodb"
import User from "@/models/User"
import Transaction from "@/models/Transaction"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    await dbConnect()

    // Get user details
    const user = await User.findOne({ email: session.user.email })

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Get direct referrals (users who used this user's referral code)
    const directReferrals = await User.find({ referredBy: user._id }).select("_id name email createdAt").lean()

    // Get all transactions where the users are direct referrals
    const directReferralTransactions = await Transaction.find({
      userId: { $in: directReferrals.map((ref) => ref._id) },
      status: "completed",
    })
      .populate("packageId", "title price")
      .populate("userId", "name email")
      .lean()

    // Enhance direct referrals with purchase info
    const enhancedDirectReferrals = directReferrals.map((referral) => {
      const userTransactions = directReferralTransactions.filter(
        (t) => t.userId._id.toString() === referral._id.toString(),
      )

      const totalSpent = userTransactions.reduce((sum, t) => sum + t.amount, 0)
      const commission = userTransactions.reduce((sum, t) => sum + (t.referralCommission || 0), 0)

      return {
        ...referral,
        purchases: userTransactions.length,
        totalSpent,
        commission,
        transactions: userTransactions.map((t) => ({
          id: t._id,
          date: t.createdAt,
          package: t.packageId?.title || "Unknown Package",
          amount: t.amount,
          commission: t.referralCommission || 0,
        })),
      }
    })

    // Get second-tier referrals (users who were referred by users who were referred by this user)
    const directReferralIds = directReferrals.map((ref) => ref._id)
    const secondTierReferrals = await User.find({
      referredBy: { $in: directReferralIds },
    })
      .select("_id name email referredBy createdAt")
      .lean()

    // Get all transactions where the users are second-tier referrals
    const secondTierTransactions = await Transaction.find({
      userId: { $in: secondTierReferrals.map((ref) => ref._id) },
      status: "completed",
    })
      .populate("packageId", "title price")
      .populate("userId", "name email")
      .lean()

    // Map second-tier referrals to their direct referrer
    const secondTierReferralsByReferrer = {}
    secondTierReferrals.forEach((referral) => {
      const referrerId = referral.referredBy.toString()
      if (!secondTierReferralsByReferrer[referrerId]) {
        secondTierReferralsByReferrer[referrerId] = []
      }
      secondTierReferralsByReferrer[referrerId].push(referral)
    })

    // Enhance second-tier referrals with purchase info
    const enhancedSecondTierReferrals = secondTierReferrals.map((referral) => {
      const userTransactions = secondTierTransactions.filter((t) => t.userId._id.toString() === referral._id.toString())

      const totalSpent = userTransactions.reduce((sum, t) => sum + t.amount, 0)
      const commission = totalSpent * 0.05 // 5% commission on second-tier

      // Find the direct referrer
      const directReferrer = directReferrals.find((dr) => dr._id.toString() === referral.referredBy.toString())

      return {
        ...referral,
        referrerName: directReferrer?.name || "Unknown",
        purchases: userTransactions.length,
        totalSpent,
        commission,
        transactions: userTransactions.map((t) => ({
          id: t._id,
          date: t.createdAt,
          package: t.packageId?.title || "Unknown Package",
          amount: t.amount,
          commission: t.amount * 0.05, // 5% commission
        })),
      }
    })

    // Calculate summary statistics
    const totalDirectCommission = enhancedDirectReferrals.reduce((sum, ref) => sum + ref.commission, 0)

    const totalSecondTierCommission = enhancedSecondTierReferrals.reduce((sum, ref) => sum + ref.commission, 0)

    return NextResponse.json({
      directReferrals: enhancedDirectReferrals,
      secondTierReferrals: enhancedSecondTierReferrals,
      summary: {
        directReferralsCount: directReferrals.length,
        secondTierReferralsCount: secondTierReferrals.length,
        totalDirectCommission,
        totalSecondTierCommission,
        totalCommission: totalDirectCommission + totalSecondTierCommission,
      },
    })
  } catch (error) {
    console.error("Error fetching referrals:", error)
    return NextResponse.json({ error: "Failed to fetch referrals" }, { status: 500 })
  }
}
