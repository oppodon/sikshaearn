import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { connectToDatabase } from "@/lib/mongodb"
import User from "@/models/User"
import Transaction from "@/models/Transaction"

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    await connectToDatabase()

    // Get user data including referral code
    const user = await User.findById(session.user.id).lean()

    if (!user) {
      return NextResponse.json({ success: false, error: "User not found" }, { status: 404 })
    }

    // Generate referral code if not exists
    let referralCode = user.referralCode
    if (!referralCode) {
      referralCode = user._id.toString().substring(0, 8)
      await User.findByIdAndUpdate(session.user.id, { referralCode })
    }

    // Get affiliate stats
    const directReferrals = await User.countDocuments({ referredBy: session.user.id })

    // Get earnings data
    const earnings = await Transaction.aggregate([
      { $match: { affiliateId: session.user.id, status: "completed" } },
      { $group: { _id: null, total: { $sum: "$affiliateCommission" } } },
    ])

    const totalEarnings = earnings.length > 0 ? earnings[0].total : 0

    // Get pending earnings
    const pendingEarnings = await Transaction.aggregate([
      { $match: { affiliateId: session.user.id, status: "pending" } },
      { $group: { _id: null, total: { $sum: "$affiliateCommission" } } },
    ])

    const totalPendingEarnings = pendingEarnings.length > 0 ? pendingEarnings[0].total : 0

    // Calculate conversion rate
    const totalClicks = user.referralClicks || 0
    const conversionRate = totalClicks > 0 ? ((directReferrals / totalClicks) * 100).toFixed(2) : 0

    // Get referral link
    const baseUrl = process.env.NEXTAUTH_URL || "https://knowledgehubnepal.com"
    const referralLink = `${baseUrl}/?ref=${referralCode}`

    return NextResponse.json({
      success: true,
      data: {
        totalEarnings,
        availableBalance: totalEarnings - totalPendingEarnings,
        totalReferrals: directReferrals,
        conversionRate,
        referralLink,
        referralCode,
      },
    })
  } catch (error) {
    console.error("Error fetching affiliate stats:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch affiliate stats" }, { status: 500 })
  }
}
