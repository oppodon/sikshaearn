import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"
import User from "@/models/User"
import Transaction from "@/models/Transaction"

export async function GET(req: NextRequest) {
  try {
    await connectToDatabase()

    const searchParams = req.nextUrl.searchParams
    const limit = Number.parseInt(searchParams.get("limit") || "10")

    // Get top affiliates by earnings
    const topAffiliatesByEarnings = await Transaction.aggregate([
      { $match: { status: "completed", affiliateId: { $exists: true } } },
      {
        $group: {
          _id: "$affiliateId",
          totalEarnings: { $sum: "$affiliateCommission" },
          totalSales: { $sum: 1 },
        },
      },
      { $sort: { totalEarnings: -1 } },
      { $limit: limit },
    ])

    // Get user details for top affiliates
    const affiliateIds = topAffiliatesByEarnings.map((affiliate) => affiliate._id)
    const affiliateUsers = await User.find({ _id: { $in: affiliateIds } })
      .select("name email image username")
      .lean()

    // Format leaderboard data
    const earningsLeaderboard = topAffiliatesByEarnings.map((affiliate, index) => {
      const user = affiliateUsers.find((u) => u._id.toString() === affiliate._id.toString())
      return {
        rank: index + 1,
        id: affiliate._id,
        name: user?.name || "Anonymous",
        username: user?.username || "user",
        image: user?.image,
        email: user?.email,
        earnings: affiliate.totalEarnings,
        sales: affiliate.totalSales,
      }
    })

    return NextResponse.json({
      success: true,
      leaderboard: earningsLeaderboard,
    })
  } catch (error) {
    console.error("Error fetching earnings leaderboard:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch earnings leaderboard" }, { status: 500 })
  }
}
