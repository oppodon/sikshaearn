import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { connectToDatabase } from "@/lib/mongodb"
import Course from "@/models/Course"
import Enrollment from "@/models/Enrollment"

export async function GET(req: NextRequest, { params }: { params: { courseid: string } }) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    await connectToDatabase()
    const { courseid } = params

    // Find course by ID
    const course = await Course.findById(courseid).lean()

    if (!course) {
      return NextResponse.json({ error: "Course not found" }, { status: 404 })
    }

    // Check if user is enrolled in this course
    const enrollment = await Enrollment.findOne({
      user: session.user.id,
      course: courseid,
    }).lean()

    if (!enrollment) {
      return NextResponse.json({ error: "Not enrolled in this course" }, { status: 403 })
    }

    // Calculate progress
    const totalLessons = course.videoLessons?.length || 0
    const completedLessons = enrollment.completedLessons?.length || 0
    const progress = totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0

    // Calculate total duration
    const totalDuration = course.videoLessons?.reduce((sum, lesson) => sum + lesson.duration, 0) || 0

    return NextResponse.json({
      course: {
        id: course._id,
        title: course.title,
        description: course.description,
        instructor: course.instructor,
        thumbnail: course.thumbnail,
        videoLessons: course.videoLessons || [],
        totalDuration,
        completedLessons: enrollment.completedLessons || [],
        currentLesson: enrollment.currentLesson || 0,
        progress,
      },
    })
  } catch (error: any) {
    console.error("Error fetching course:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
