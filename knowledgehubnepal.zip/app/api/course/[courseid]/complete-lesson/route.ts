import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { connectToDatabase } from "@/lib/mongodb"
import Enrollment from "@/models/Enrollment"

export async function POST(req: NextRequest, { params }: { params: { courseid: string } }) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    await connectToDatabase()
    const { courseid } = params
    const { lessonId } = await req.json()

    // Find enrollment
    const enrollment = await Enrollment.findOne({
      user: session.user.id,
      course: courseid,
    })

    if (!enrollment) {
      return NextResponse.json({ error: "Not enrolled in this course" }, { status: 403 })
    }

    // Add lesson to completed lessons if not already completed
    if (!enrollment.completedLessons.includes(lessonId)) {
      enrollment.completedLessons.push(lessonId)
      await enrollment.save()
    }

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("Error completing lesson:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
