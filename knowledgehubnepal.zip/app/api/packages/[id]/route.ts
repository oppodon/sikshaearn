import { NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"
import Package from "@/models/Package"
import { ObjectId } from "mongodb"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    await connectToDatabase()
    const { id } = params

    // Check if id is a valid ObjectId
    if (!ObjectId.isValid(id)) {
      return NextResponse.json({ error: "Invalid package ID format" }, { status: 400 })
    }

    // Find package by ID
    const packageData = await Package.findById(id).lean()

    if (!packageData) {
      return NextResponse.json({ error: "Package not found" }, { status: 404 })
    }

    return NextResponse.json({ package: packageData })
  } catch (error: any) {
    console.error("Error fetching package:", error)
    return NextResponse.json({ error: error.message || "Failed to fetch package" }, { status: 500 })
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    await connectToDatabase()
    const { id } = params
    const data = await request.json()

    // Check if id is a valid ObjectId
    if (!ObjectId.isValid(id)) {
      return NextResponse.json({ error: "Invalid package ID format" }, { status: 400 })
    }

    // Find and update package
    const updatedPackage = await Package.findByIdAndUpdate(id, data, { new: true }).lean()

    if (!updatedPackage) {
      return NextResponse.json({ error: "Package not found" }, { status: 404 })
    }

    return NextResponse.json({ package: updatedPackage })
  } catch (error: any) {
    console.error("Error updating package:", error)
    return NextResponse.json({ error: error.message || "Failed to update package" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    await connectToDatabase()
    const { id } = params

    // Check if id is a valid ObjectId
    if (!ObjectId.isValid(id)) {
      return NextResponse.json({ error: "Invalid package ID format" }, { status: 400 })
    }

    // Find and delete package
    const deletedPackage = await Package.findByIdAndDelete(id).lean()

    if (!deletedPackage) {
      return NextResponse.json({ error: "Package not found" }, { status: 404 })
    }

    return NextResponse.json({ message: "Package deleted successfully" })
  } catch (error: any) {
    console.error("Error deleting package:", error)
    return NextResponse.json({ error: error.message || "Failed to delete package" }, { status: 500 })
  }
}
