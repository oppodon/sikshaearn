import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"
import Package from "@/models/Package"

export async function GET(req: NextRequest) {
  try {
    await connectToDatabase()

    // Get all packages
    const packages = await Package.find({})
      .sort({ price: 1 })
      .select("name slug description price thumbnail isPopular")
      .lean()

    return NextResponse.json({ success: true, packages }, { status: 200 })
  } catch (error) {
    console.error("Error fetching packages:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch packages. Please try again." }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    await connectToDatabase()

    const data = await req.json()

    // Create slug from name
    const slug = data.name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "")

    // Check if slug already exists
    const existingPackage = await Package.findOne({ slug })
    if (existingPackage) {
      return NextResponse.json({ success: false, error: "A package with this name already exists." }, { status: 400 })
    }

    // Create new package with simplified fields
    const newPackage = await Package.create({
      name: data.name,
      slug,
      description: data.description,
      price: data.price,
      thumbnail: data.thumbnail || "/placeholder.svg?height=200&width=300",
      isPopular: data.isPopular || false,
    })

    return NextResponse.json({ success: true, package: newPackage }, { status: 201 })
  } catch (error: any) {
    console.error("Error creating package:", error)

    if (error.code === 11000) {
      return NextResponse.json({ success: false, error: "A package with this slug already exists." }, { status: 400 })
    }

    return NextResponse.json({ success: false, error: "Failed to create package. Please try again." }, { status: 500 })
  }
}
