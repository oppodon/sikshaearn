import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { connectToDatabase } from "@/lib/mongodb"
import Transaction from "@/models/Transaction"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    // Check if user is authenticated and is an admin
    if (!session || !session.user || session.user.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    await connectToDatabase()

    // Get the request body
    const body = await req.json()
    const { transactionId, reason } = body

    if (!transactionId) {
      return NextResponse.json({ error: "Transaction ID is required" }, { status: 400 })
    }

    if (!reason) {
      return NextResponse.json({ error: "Rejection reason is required" }, { status: 400 })
    }

    // Find the transaction
    const transaction = await Transaction.findById(transactionId)
      .populate("user", "name email")
      .populate("package", "title")

    if (!transaction) {
      return NextResponse.json({ error: "Transaction not found" }, { status: 404 })
    }

    if (transaction.status === "rejected") {
      return NextResponse.json({ error: "Transaction is already rejected" }, { status: 400 })
    }

    // Update transaction status
    transaction.status = "rejected"
    transaction.rejectionReason = reason
    await transaction.save()

    return NextResponse.json({
      success: true,
      message: "Transaction rejected successfully",
      transaction,
    })
  } catch (error) {
    console.error("Error rejecting transaction:", error)
    return NextResponse.json({ error: "An error occurred while rejecting the transaction" }, { status: 500 })
  }
}
