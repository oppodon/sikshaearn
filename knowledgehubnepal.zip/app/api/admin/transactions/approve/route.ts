import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { connectToDatabase } from "@/lib/mongodb"
import Transaction from "@/models/Transaction"
import User from "@/models/User"
import Enrollment from "@/models/Enrollment"
import Package from "@/models/Package"

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions)

    // Check if user is authenticated and is an admin
    if (!session?.user || session.user.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { transactionId } = await req.json()

    if (!transactionId) {
      return NextResponse.json({ error: "Transaction ID is required" }, { status: 400 })
    }

    await connectToDatabase()

    // Find the transaction
    const transaction = await Transaction.findById(transactionId)

    if (!transaction) {
      return NextResponse.json({ error: "Transaction not found" }, { status: 404 })
    }

    // If transaction is already approved, return success
    if (transaction.status === "completed") {
      return NextResponse.json({ success: true, message: "Transaction already approved" })
    }

    // Get package details - don't populate courses to avoid schema error
    const packageData = await Package.findById(transaction.package)

    if (!packageData) {
      return NextResponse.json({ error: "Package not found" }, { status: 404 })
    }

    // Update transaction status to completed (not approved)
    transaction.status = "completed"
    transaction.approvedAt = new Date()
    transaction.approvedBy = session.user.id
    await transaction.save()

    // Get courses associated with this package
    const packageWithCourses = await Package.findById(transaction.package).lean()
    const courseIds = packageWithCourses?.courses || []

    // Create enrollments for all courses in the package if courses exist
    if (courseIds && courseIds.length > 0) {
      const enrollmentPromises = courseIds.map((courseId: string) => {
        return Enrollment.create({
          user: transaction.user,
          course: courseId,
          package: packageData._id,
          transaction: transaction._id,
          status: "active",
        })
      })

      await Promise.all(enrollmentPromises)
    }

    // If this was a referred transaction, update the referrer's earnings
    if (transaction.referredBy && transaction.commissionAmount) {
      await User.findByIdAndUpdate(transaction.referredBy, {
        $inc: {
          totalEarnings: transaction.commissionAmount,
          availableBalance: transaction.commissionAmount,
        },
        $push: {
          referralActivity: {
            action: "commission",
            timestamp: new Date(),
            details: {
              transactionId: transaction._id,
              amount: transaction.commissionAmount,
              packageTitle: packageData.title || packageData.name,
            },
          },
        },
      })
    }

    return NextResponse.json({
      success: true,
      message: "Transaction approved and enrollments created",
    })
  } catch (error) {
    console.error("Error approving transaction:", error)
    return NextResponse.json({ error: "Failed to approve transaction" }, { status: 500 })
  }
}
