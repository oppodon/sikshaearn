import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { connectToDatabase } from "@/lib/mongodb"
import Course from "@/models/Course"

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const status = searchParams.get("status")
    const category = searchParams.get("category")
    const search = searchParams.get("search")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const skip = (page - 1) * limit

    await connectToDatabase()

    // Build query
    const query: any = {}
    if (status) query.status = status
    if (category) query.category = category
    if (search) {
      query.$or = [{ title: { $regex: search, $options: "i" } }, { description: { $regex: search, $options: "i" } }]
    }

    // Execute query
    const courses = await Course.find(query).sort({ createdAt: -1 }).skip(skip).limit(limit).lean()

    const total = await Course.countDocuments(query)

    return NextResponse.json({
      courses,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error: any) {
    console.error("Error fetching courses:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user || session.user.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const data = await req.json()

    // Validate required fields
    if (!data.title) {
      return NextResponse.json({ error: "Title is required" }, { status: 400 })
    }

    await connectToDatabase()

    // Create slug from title
    const slug = data.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "")

    // Check if slug already exists
    const existingCourse = await Course.findOne({ slug })
    if (existingCourse) {
      return NextResponse.json({ error: "A course with this title already exists" }, { status: 400 })
    }

    // Format video lessons
    const videoLessons = data.videoLessons.map((lesson) => ({
      title: lesson.title,
      videoUrl: lesson.videoUrl,
      duration: Number(lesson.duration),
    }))

    // Create new course
    const course = new Course({
      title: data.title,
      slug,
      description: data.description,
      instructor: data.instructor,
      thumbnail: data.thumbnail || "/placeholder.svg?height=200&width=300",
      videoLessons: videoLessons,
      packages: data.packages || [],
      createdBy: session.user.id,
    })

    await course.save()

    return NextResponse.json({ course }, { status: 201 })
  } catch (error: any) {
    console.error("Error creating course:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
