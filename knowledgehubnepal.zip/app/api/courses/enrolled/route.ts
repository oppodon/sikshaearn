import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { connectToDatabase } from "@/lib/mongodb"
import Enrollment from "@/models/Enrollment"
import Course from "@/models/Course"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: "You must be logged in to view enrolled courses" }, { status: 401 })
    }

    await connectToDatabase()

    // Find all enrollments for the user
    const enrollments = await Enrollment.find({
      user: session.user.id,
    })
      .populate("package")
      .lean()

    if (!enrollments || enrollments.length === 0) {
      return NextResponse.json({ courses: [] })
    }

    // Get course IDs from enrollments
    const courseIds = []
    const packageMap = new Map()

    // Create a map of package IDs to package names
    for (const enrollment of enrollments) {
      if (enrollment.package && enrollment.package._id) {
        packageMap.set(enrollment.package._id.toString(), enrollment.package.name)

        // If the package has courses, add them to courseIds
        if (enrollment.package.courses && enrollment.package.courses.length > 0) {
          courseIds.push(...enrollment.package.courses)
        }
      }
    }

    // Find all courses the user is enrolled in
    const courses = await Course.find({
      _id: { $in: courseIds },
    })
      .select("title slug description thumbnail instructor videoLessons")
      .lean()

    // Add enrollment data and package name to each course
    const coursesWithProgress = await Promise.all(
      courses.map(async (course) => {
        // Find which package(s) this course belongs to
        const packageNames = []

        for (const enrollment of enrollments) {
          if (
            enrollment.package &&
            enrollment.package.courses &&
            enrollment.package.courses.some((c: any) => c.toString() === course._id.toString())
          ) {
            packageNames.push(enrollment.package.name)
          }
        }

        // Find enrollment data for this course
        const courseEnrollment = await Enrollment.findOne({
          user: session.user.id,
          completedCourses: { $ne: course._id },
        }).lean()

        return {
          ...course,
          packageName: packageNames.length > 0 ? packageNames.join(", ") : "Individual Course",
          progress: courseEnrollment?.progress || 0,
          completedLessons: courseEnrollment?.completedLessons || [],
          lastAccessed: courseEnrollment?.lastAccessed || null,
          enrolledAt: courseEnrollment?.createdAt || null,
        }
      }),
    )

    return NextResponse.json({ courses: coursesWithProgress })
  } catch (error) {
    console.error("Error fetching enrolled courses:", error)
    return NextResponse.json({ error: "Failed to fetch enrolled courses" }, { status: 500 })
  }
}
