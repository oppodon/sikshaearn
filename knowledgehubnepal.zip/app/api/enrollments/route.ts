import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"
import Enrollment from "@/models/Enrollment"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    await connectToDatabase()

    // Get user's enrollments
    const enrollments = await Enrollment.find({ user: session.user.id, isActive: true })
      .populate("package", "title slug description thumbnail courseCount")
      .sort({ createdAt: -1 })
      .lean()

    return NextResponse.json({ success: true, enrollments }, { status: 200 })
  } catch (error) {
    console.error("Error fetching enrollments:", error)
    return NextResponse.json(
      { success: false, error: "Failed to fetch enrollments. Please try again." },
      { status: 500 },
    )
  }
}
