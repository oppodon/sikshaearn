"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useSession } from "next-auth/react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/components/ui/use-toast"
import { CheckCircle, ArrowLeft, Info, AlertCircle } from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface PackageData {
  _id: string
  name: string
  title: string
  description: string
  price: number
  originalPrice: number
  features: string[]
  thumbnail: string
}

export default function CheckoutPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { data: session, status } = useSession()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [packageData, setPackageData] = useState<PackageData | null>(null)
  const [promoCode, setPromoCode] = useState("")
  const [discount, setDiscount] = useState(0)
  const [isPromoValid, setIsPromoValid] = useState(false)
  const [isPromoLoading, setIsPromoLoading] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState("bank-transfer")
  const [referralCode, setReferralCode] = useState("")
  const [referralApplied, setReferralApplied] = useState(false)
  const [referralDiscount, setReferralDiscount] = useState(0)

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push(`/login?callbackUrl=/packages/${params.id}/checkout`)
      return
    }

    const fetchPackageData = async () => {
      try {
        setIsLoading(true)
        const response = await fetch(`/api/packages/${params.id}`)

        if (!response.ok) {
          throw new Error("Failed to fetch package data")
        }

        const data = await response.json()
        setPackageData(data.package)
      } catch (error) {
        console.error("Error fetching package:", error)
        toast({
          title: "Error",
          description: "Failed to load package data. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    if (status === "authenticated") {
      fetchPackageData()
    }
  }, [params.id, router, status, toast])

  const handlePromoCodeValidation = async () => {
    if (!promoCode.trim()) return

    try {
      setIsPromoLoading(true)
      const response = await fetch(`/api/promo/validate?code=${promoCode}&packageId=${params.id}`)
      const data = await response.json()

      if (response.ok && data.valid) {
        setIsPromoValid(true)
        setDiscount(data.discountAmount || 0)
        toast({
          title: "Promo code applied!",
          description: `You've received a discount of ₹${data.discountAmount}.`,
        })
      } else {
        setIsPromoValid(false)
        setDiscount(0)
        toast({
          title: "Invalid promo code",
          description: data.message || "This promo code is invalid or expired.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error validating promo code:", error)
      toast({
        title: "Error",
        description: "Failed to validate promo code. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsPromoLoading(false)
    }
  }

  const handleReferralCodeValidation = async () => {
    if (!referralCode.trim()) return

    try {
      setIsPromoLoading(true)
      const response = await fetch(`/api/referral/validate?code=${referralCode}&packageId=${params.id}`)
      const data = await response.json()

      if (response.ok && data.valid) {
        setReferralApplied(true)
        setReferralDiscount(data.discountAmount || 0)
        toast({
          title: "Referral code applied!",
          description: `You've received a discount of ₹${data.discountAmount}.`,
        })
      } else {
        setReferralApplied(false)
        setReferralDiscount(0)
        toast({
          title: "Invalid referral code",
          description: data.message || "This referral code is invalid or expired.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error validating referral code:", error)
      toast({
        title: "Error",
        description: "Failed to validate referral code. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsPromoLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!packageData) return

    try {
      setIsSubmitting(true)

      const transactionData = {
        packageId: params.id,
        amount: packageData.price - discount - referralDiscount,
        paymentMethod,
        promoCode: isPromoValid ? promoCode : null,
        referralCode: referralApplied ? referralCode : null,
      }

      const response = await fetch("/api/transactions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(transactionData),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to process payment")
      }

      toast({
        title: "Payment initiated!",
        description: "Your payment request has been submitted. Please complete the payment.",
      })

      // Redirect to payment confirmation page
      router.push(`/payment/confirmation/${data.transactionId}`)
    } catch (error: any) {
      console.error("Error processing payment:", error)
      toast({
        title: "Payment Error",
        description: error.message || "Failed to process payment. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  if (status === "loading" || isLoading) {
    return (
      <div className="container max-w-5xl mx-auto py-12 px-4">
        <div className="flex items-center gap-2 mb-8">
          <Button variant="outline" size="icon" disabled>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <Skeleton className="h-8 w-64" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-6">
            <Skeleton className="h-10 w-full max-w-md" />
            <Skeleton className="h-64 w-full" />
          </div>
          <div>
            <Skeleton className="h-96 w-full" />
          </div>
        </div>
      </div>
    )
  }

  if (!packageData) {
    return (
      <div className="container max-w-5xl mx-auto py-12 px-4">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>
            Failed to load package data. Please try again or{" "}
            <Link href="/packages" className="underline">
              return to packages
            </Link>
            .
          </AlertDescription>
        </Alert>
      </div>
    )
  }

  const subtotal = packageData.price
  const totalDiscount = discount + referralDiscount
  const total = subtotal - totalDiscount

  return (
    <div className="container max-w-5xl mx-auto py-12 px-4">
      <div className="flex items-center gap-2 mb-8">
        <Button variant="outline" size="icon" asChild>
          <Link href={`/packages/${params.id}`}>
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <h1 className="text-2xl font-bold">Checkout</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <form onSubmit={handleSubmit} className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>Payment Method</CardTitle>
                <CardDescription>Select your preferred payment method</CardDescription>
              </CardHeader>
              <CardContent>
                <RadioGroup
                  value={paymentMethod}
                  onValueChange={setPaymentMethod}
                  className="space-y-4"
                  defaultValue="bank-transfer"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="bank-transfer" id="bank-transfer" />
                    <Label htmlFor="bank-transfer" className="flex items-center">
                      <Image
                        src="/images/payment/bank-transfer.png"
                        alt="Bank Transfer"
                        width={32}
                        height={32}
                        className="mr-2"
                      />
                      Bank Transfer
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="esewa" id="esewa" />
                    <Label htmlFor="esewa" className="flex items-center">
                      <Image src="/images/payment/esewa.png" alt="eSewa" width={32} height={32} className="mr-2" />
                      eSewa
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="khalti" id="khalti" />
                    <Label htmlFor="khalti" className="flex items-center">
                      <Image src="/images/payment/khalti.png" alt="Khalti" width={32} height={32} className="mr-2" />
                      Khalti
                    </Label>
                  </div>
                </RadioGroup>

                {paymentMethod === "bank-transfer" && (
                  <div className="mt-4 p-4 bg-muted rounded-md">
                    <h3 className="font-medium mb-2">Bank Transfer Instructions</h3>
                    <p className="text-sm text-muted-foreground mb-2">
                      Please transfer the total amount to the following bank account:
                    </p>
                    <div className="space-y-1 text-sm">
                      <p>
                        <span className="font-medium">Bank Name:</span> Nepal Bank Ltd
                      </p>
                      <p>
                        <span className="font-medium">Account Name:</span> Knowledge Hub Nepal
                      </p>
                      <p>
                        <span className="font-medium">Account Number:</span> 0123456789012
                      </p>
                      <p>
                        <span className="font-medium">Branch:</span> Kathmandu
                      </p>
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">
                      After making the payment, please upload the payment receipt on the next page.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Promo & Referral</CardTitle>
                <CardDescription>Apply promo code or referral code if you have one</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="promo-code">Promo Code</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="promo-code"
                      placeholder="Enter promo code"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      disabled={isPromoValid || isPromoLoading}
                      className={isPromoValid ? "border-green-500" : ""}
                    />
                    <Button
                      type="button"
                      variant={isPromoValid ? "outline" : "default"}
                      onClick={handlePromoCodeValidation}
                      disabled={isPromoValid || isPromoLoading || !promoCode.trim()}
                    >
                      {isPromoValid ? (
                        <>
                          <CheckCircle className="mr-2 h-4 w-4" />
                          Applied
                        </>
                      ) : isPromoLoading ? (
                        "Validating..."
                      ) : (
                        "Apply"
                      )}
                    </Button>
                  </div>
                  {isPromoValid && (
                    <p className="text-sm text-green-600 flex items-center">
                      <CheckCircle className="mr-1 h-3 w-3" /> Promo code applied successfully!
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="referral-code">Referral Code</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="referral-code"
                      placeholder="Enter referral code"
                      value={referralCode}
                      onChange={(e) => setReferralCode(e.target.value)}
                      disabled={referralApplied || isPromoLoading}
                      className={referralApplied ? "border-green-500" : ""}
                    />
                    <Button
                      type="button"
                      variant={referralApplied ? "outline" : "default"}
                      onClick={handleReferralCodeValidation}
                      disabled={referralApplied || isPromoLoading || !referralCode.trim()}
                    >
                      {referralApplied ? (
                        <>
                          <CheckCircle className="mr-2 h-4 w-4" />
                          Applied
                        </>
                      ) : isPromoLoading ? (
                        "Validating..."
                      ) : (
                        "Apply"
                      )}
                    </Button>
                  </div>
                  {referralApplied && (
                    <p className="text-sm text-green-600 flex items-center">
                      <CheckCircle className="mr-1 h-3 w-3" /> Referral code applied successfully!
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Button type="submit" className="w-full" size="lg" disabled={isSubmitting}>
              {isSubmitting ? "Processing..." : `Complete Payment (₹${total.toFixed(2)})`}
            </Button>
          </form>
        </div>

        <div>
          <Card className="sticky top-8">
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="relative w-20 h-20 rounded-md overflow-hidden">
                  <Image
                    src={packageData.thumbnail || "/placeholder.svg?height=80&width=80"}
                    alt={packageData.title}
                    fill
                    className="object-cover"
                  />
                </div>
                <div>
                  <h3 className="font-medium">{packageData.title}</h3>
                  <p className="text-sm text-muted-foreground">{packageData.description.substring(0, 60)}...</p>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>₹{subtotal.toFixed(2)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>Promo Discount</span>
                    <span>-₹{discount.toFixed(2)}</span>
                  </div>
                )}
                {referralDiscount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>Referral Discount</span>
                    <span>-₹{referralDiscount.toFixed(2)}</span>
                  </div>
                )}
                <Separator />
                <div className="flex justify-between font-medium text-lg">
                  <span>Total</span>
                  <span>₹{total.toFixed(2)}</span>
                </div>
              </div>

              <div className="bg-muted p-3 rounded-md text-sm">
                <div className="flex gap-2">
                  <Info className="h-4 w-4 text-muted-foreground flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium">What's included:</p>
                    <ul className="mt-1 space-y-1">
                      {packageData.features &&
                      Array.isArray(packageData.features) &&
                      packageData.features.length > 0 ? (
                        packageData.features.slice(0, 4).map((feature, index) => (
                          <li key={index} className="flex items-start gap-1">
                            <CheckCircle className="h-3 w-3 text-green-600 flex-shrink-0 mt-0.5" />
                            <span className="text-muted-foreground">{feature}</span>
                          </li>
                        ))
                      ) : (
                        <li className="flex items-start gap-1">
                          <CheckCircle className="h-3 w-3 text-green-600 flex-shrink-0 mt-0.5" />
                          <span className="text-muted-foreground">Access to all courses in this package</span>
                        </li>
                      )}
                      {packageData.features &&
                        Array.isArray(packageData.features) &&
                        packageData.features.length > 4 && (
                          <li className="text-muted-foreground text-xs">+ {packageData.features.length - 4} more</li>
                        )}
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-2">
              <p className="text-xs text-muted-foreground text-center">
                By completing this purchase, you agree to our{" "}
                <Link href="/terms" className="underline">
                  Terms of Service
                </Link>{" "}
                and{" "}
                <Link href="/privacy" className="underline">
                  Privacy Policy
                </Link>
                .
              </p>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}
