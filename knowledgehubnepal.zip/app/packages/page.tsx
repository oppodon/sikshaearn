import { Suspense } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, Star, Users, BookOpen } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { connectToDatabase } from "@/lib/mongodb"
import Package from "@/models/Package"

// Loading component for packages
function PackagesSkeleton() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
      {[1, 2, 3, 4].map((i) => (
        <Card key={i} className="flex flex-col relative overflow-hidden">
          <Skeleton className="h-40 w-full" />
          <CardHeader className="text-center pt-4 pb-2">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Skeleton className="h-4 w-24" />
            </div>
            <div className="flex items-center justify-center gap-4 text-sm mb-2">
              <Skeleton className="h-4 w-20" />
              <Skeleton className="h-4 w-20" />
            </div>
            <Skeleton className="h-8 w-32 mx-auto" />
            <Skeleton className="h-4 w-full mt-2" />
          </CardHeader>
          <CardContent className="flex-grow">
            <div className="space-y-3">
              {[1, 2, 3, 4].map((j) => (
                <div key={j} className="flex items-start">
                  <Skeleton className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                  <Skeleton className="h-5 w-full" />
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter className="pt-2 pb-6">
            <Skeleton className="h-10 w-full" />
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

// Fetch packages from database
async function getPackages() {
  await connectToDatabase()

  const packages = await Package.find({})
    .sort({ price: 1 })
    .select("title slug description price originalPrice thumbnail isPopular courseCount studentCount features")
    .lean()

  return packages
}

export default async function PackagesPage() {
  const packages = await getPackages()

  return (
    <div className="bg-gradient-to-b from-slate-50 to-white">
      <div className="container py-12 px-4 mx-auto max-w-7xl">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">Choose Your Learning Path</h1>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Select the package that best fits your learning goals and budget. Each package is designed to provide
            maximum value and help you achieve your career goals.
          </p>
        </div>

        <Suspense fallback={<PackagesSkeleton />}>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {packages.map((pkg) => (
              <Card
                key={pkg._id.toString()}
                className={`flex flex-col relative overflow-hidden ${pkg.isPopular ? "border-primary shadow-lg" : ""}`}
              >
                {pkg.isPopular && (
                  <div className="absolute top-0 right-0 -mt-2 -mr-2 z-10">
                    <Badge className="bg-primary">MOST POPULAR</Badge>
                  </div>
                )}

                <div className="relative h-40 w-full">
                  <Image
                    src={pkg.thumbnail || "/placeholder.svg?height=200&width=300"}
                    alt={pkg.title}
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
                    <h3 className="text-white text-xl font-bold">{pkg.title}</h3>
                  </div>
                </div>

                <CardHeader className="text-center pt-4 pb-2">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star key={star} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground mb-2">
                    <div className="flex items-center">
                      <BookOpen className="h-4 w-4 mr-1" />
                      {pkg.courseCount} Courses
                    </div>
                    <div className="flex items-center">
                      <Users className="h-4 w-4 mr-1" />
                      {pkg.studentCount}+ Students
                    </div>
                  </div>
                  <div className="flex items-center justify-center gap-2">
                    <CardTitle className="text-3xl font-bold">₹{pkg.price}</CardTitle>
                    {pkg.originalPrice && (
                      <span className="text-muted-foreground line-through">₹{pkg.originalPrice}</span>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">{pkg.description}</p>
                </CardHeader>

                <CardContent className="flex-grow">
                  <ul className="space-y-3">
                    {/* Check if features exists and is an array before mapping */}
                    {Array.isArray(pkg.features) && pkg.features.length > 0 ? (
                      pkg.features.map((feature, index) => (
                        <li key={index} className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-primary mr-2 mt-0.5 flex-shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ))
                    ) : (
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-primary mr-2 mt-0.5 flex-shrink-0" />
                        <span>Access to all courses in this package</span>
                      </li>
                    )}
                  </ul>
                </CardContent>

                <CardFooter className="pt-2 pb-6">
                  <Button asChild className="w-full">
                    <Link href={`/packages/${pkg._id.toString()}`}>View Package Details</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </Suspense>

        <div className="mt-16 text-center">
          <h2 className="text-2xl font-bold mb-4">Need Help Choosing?</h2>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Not sure which package is right for you? Contact our education advisors for personalized guidance.
          </p>
          <Button asChild variant="outline" size="lg">
            <Link href="/contact">Contact an Advisor</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
