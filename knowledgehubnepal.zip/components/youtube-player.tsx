"use client"

import { useEffect, useRef, useState } from "react"

declare global {
  interface Window {
    YT: {
      Player: new (
        elementId: string,
        options: {
          videoId: string
          playerVars?: {
            autoplay?: 0 | 1
            controls?: 0 | 1
            rel?: 0 | 1
            showinfo?: 0 | 1
            mute?: 0 | 1
            modestbranding?: 0 | 1
          }
          events?: {
            onReady?: (event: any) => void
            onStateChange?: (event: any) => void
            onError?: (event: any) => void
          }
        },
      ) => void
    }
    onYouTubeIframeAPIReady: () => void
  }
}

interface YoutubePlayerProps {
  videoId: string
  autoplay?: boolean
  onReady?: () => void
  onEnd?: () => void
}

export function YoutubePlayer({ videoId, autoplay = false, onReady, onEnd }: YoutubePlayerProps) {
  const playerRef = useRef<any>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    // Load YouTube API script
    const tag = document.createElement("script")
    tag.src = "https://www.youtube.com/iframe_api"
    const firstScriptTag = document.getElementsByTagName("script")[0]
    firstScriptTag.parentNode?.insertBefore(tag, firstScriptTag)

    // Initialize player when API is ready
    const onYouTubeIframeAPIReady = () => {
      if (!containerRef.current) return

      try {
        playerRef.current = new window.YT.Player(`youtube-player-${videoId}`, {
          videoId,
          playerVars: {
            autoplay: autoplay ? 1 : 0,
            controls: 1,
            rel: 0,
            showinfo: 0,
            mute: 0,
            modestbranding: 1,
          },
          events: {
            onReady: (event) => {
              setIsLoading(false)
              if (onReady) onReady()
            },
            onStateChange: (event) => {
              // State 0 means video ended
              if (event.data === 0 && onEnd) {
                onEnd()
              }
            },
            onError: (event) => {
              setError("Error loading video. Please try again later.")
              setIsLoading(false)
            },
          },
        })
      } catch (err) {
        setError("Error initializing video player.")
        setIsLoading(false)
      }
    }

    // Set up global callback for YouTube API
    if (window.YT && window.YT.Player) {
      onYouTubeIframeAPIReady()
    } else {
      window.onYouTubeIframeAPIReady = onYouTubeIframeAPIReady
    }

    // Cleanup
    return () => {
      if (playerRef.current && playerRef.current.destroy) {
        playerRef.current.destroy()
      }
    }
  }, [videoId, autoplay, onReady, onEnd])

  // Update video when videoId changes
  useEffect(() => {
    if (playerRef.current && playerRef.current.loadVideoById) {
      playerRef.current.loadVideoById(videoId)
    }
  }, [videoId])

  return (
    <div className="relative w-full h-full">
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      )}

      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50">
          <div className="text-white bg-red-500/20 p-4 rounded-md max-w-md text-center">
            <p>{error}</p>
          </div>
        </div>
      )}

      <div ref={containerRef} id={`youtube-player-${videoId}`} className="w-full h-full"></div>
    </div>
  )
}
