import nodemailer from "nodemailer"

// Create Gmail SMTP transporter
const createTransporter = () => {
  if (!process.env.EMAIL_SERVER_USER || !process.env.EMAIL_SERVER_PASSWORD) {
    console.log("Gmail credentials not configured, emails will be logged only")
    return null
  }

  return nodemailer.createTransporter({
    service: "gmail",
    auth: {
      user: process.env.EMAIL_SERVER_USER,
      pass: process.env.EMAIL_SERVER_PASSWORD, // Use App Password, not regular password
    },
  })
}

function getBaseUrl() {
  // For Vercel deployments
  if (process.env.VERCEL_URL) {
    return `https://${process.env.VERCEL_URL}`
  }
  // For custom domains on Vercel or other hosting
  if (process.env.NEXTAUTH_URL) {
    return process.env.NEXTAUTH_URL
  }
  // Fallback for local development
  return "http://localhost:3000"
}

// Export the sendEmail function
export async function sendEmail({
  to,
  subject,
  html,
  text,
}: {
  to: string
  subject: string
  html: string
  text?: string
}) {
  const transporter = createTransporter()

  if (!transporter) {
    console.log("Email would be sent (Gmail not configured):", { to, subject })
    return { success: true, data: { id: "mock-email-id" } }
  }

  try {
    const result = await transporter.sendMail({
      from: `"Knowledge Hub Nepal" <${process.env.EMAIL_SERVER_USER}>`,
      to,
      subject,
      html,
      text: text || html.replace(/<[^>]*>/g, ""),
    })

    console.log("Email sent successfully:", result.messageId)
    return { success: true, data: result }
  } catch (error) {
    console.error("Failed to send email:", error)
    return { success: false, error }
  }
}

export const sendVerificationEmail = async (email: string, token: string) => {
  const baseUrl = getBaseUrl()
  const confirmLink = `${baseUrl}/verify-email?token=${token}`

  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Verify Your Email - Knowledge Hub Nepal</title>
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
        <h1 style="color: white; margin: 0; font-size: 28px;">Welcome to Knowledge Hub Nepal!</h1>
      </div>
      
      <div style="background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px;">
        <h2 style="color: #333; margin-top: 0;">Verify Your Email Address</h2>
        
        <p>Thank you for registering with Knowledge Hub Nepal! To complete your registration and start your learning journey, please verify your email address.</p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${confirmLink}" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">Verify Email Address</a>
        </div>
        
        <p>If the button doesn't work, copy and paste this link into your browser:</p>
        <p style="word-break: break-all; background: #e9e9e9; padding: 10px; border-radius: 5px;">${confirmLink}</p>
        
        <p><strong>This verification link will expire in 24 hours.</strong></p>
        
        <hr style="border: none; border-top: 1px solid #ddd; margin: 30px 0;">
        
        <p style="font-size: 14px; color: #666;">
          If you didn't create an account with Knowledge Hub Nepal, please ignore this email.
        </p>
        
        <p style="font-size: 14px; color: #666;">
          Best regards,<br>
          Knowledge Hub Nepal Team
        </p>
      </div>
    </body>
    </html>
  `

  return sendEmail({
    to: email,
    subject: "Verify Your Email - Knowledge Hub Nepal",
    html,
  })
}

export const sendPasswordResetEmail = async (email: string, token: string) => {
  const baseUrl = getBaseUrl()
  const resetLink = `${baseUrl}/reset-password?token=${token}`

  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Reset Your Password - Knowledge Hub Nepal</title>
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
        <h1 style="color: white; margin: 0; font-size: 28px;">Password Reset Request</h1>
      </div>
      
      <div style="background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px;">
        <h2 style="color: #333; margin-top: 0;">Reset Your Password</h2>
        
        <p>We received a request to reset your password for your Knowledge Hub Nepal account.</p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${resetLink}" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">Reset Password</a>
        </div>
        
        <p>If the button doesn't work, copy and paste this link into your browser:</p>
        <p style="word-break: break-all; background: #e9e9e9; padding: 10px; border-radius: 5px;">${resetLink}</p>
        
        <p><strong>This reset link will expire in 1 hour.</strong></p>
        
        <hr style="border: none; border-top: 1px solid #ddd; margin: 30px 0;">
        
        <p style="font-size: 14px; color: #666;">
          If you didn't request a password reset, please ignore this email. Your password will remain unchanged.
        </p>
        
        <p style="font-size: 14px; color: #666;">
          Best regards,<br>
          Knowledge Hub Nepal Team
        </p>
      </div>
    </body>
    </html>
  `

  return sendEmail({
    to: email,
    subject: "Reset Your Password - Knowledge Hub Nepal",
    html,
  })
}

export async function sendWithdrawalStatusEmail({
  email,
  name,
  status,
  amount,
  transactionId,
  reason,
  method,
  date,
}: {
  email: string
  name: string
  status: "approved" | "rejected"
  amount: number
  transactionId?: string
  reason?: string
  method: string
  date: string
}) {
  const formattedAmount = new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount)

  const formattedDate = new Date(date).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  })

  const methodDisplay =
    {
      bank_transfer: "Bank Transfer",
      esewa: "eSewa",
      khalti: "Khalti",
    }[method] || method

  let subject = ""
  let content = ""

  if (status === "approved") {
    subject = "Your Withdrawal Request Has Been Approved"
    content = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">Withdrawal Approved</h1>
        </div>
        
        <div style="background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px;">
          <p>Hello ${name},</p>
          <p>Your withdrawal request for ${formattedAmount} has been approved and processed.</p>
          
          <div style="background-color: #e8f5e8; padding: 15px; border-radius: 5px; margin: 20px 0; border-left: 4px solid #4CAF50;">
            <h3 style="margin-top: 0; color: #2e7d32;">Withdrawal Details</h3>
            <p><strong>Amount:</strong> ${formattedAmount}</p>
            <p><strong>Method:</strong> ${methodDisplay}</p>
            <p><strong>Transaction ID:</strong> ${transactionId}</p>
            <p><strong>Date Processed:</strong> ${formattedDate}</p>
          </div>
          
          <p>The funds should be available in your account within 1-3 business days, depending on your payment method.</p>
          <p>If you have any questions, please contact our support team.</p>
          
          <p>Thank you for being a valued affiliate with Knowledge Hub Nepal.</p>
          
          <p>Best regards,<br>
          Knowledge Hub Nepal Team</p>
        </div>
      </div>
    `
  } else {
    subject = "Your Withdrawal Request Has Been Rejected"
    content = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #F44336 0%, #d32f2f 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">Withdrawal Rejected</h1>
        </div>
        
        <div style="background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px;">
          <p>Hello ${name},</p>
          <p>We regret to inform you that your withdrawal request for ${formattedAmount} has been rejected.</p>
          
          <div style="background-color: #ffebee; padding: 15px; border-radius: 5px; margin: 20px 0; border-left: 4px solid #F44336;">
            <h3 style="margin-top: 0; color: #c62828;">Withdrawal Details</h3>
            <p><strong>Amount:</strong> ${formattedAmount}</p>
            <p><strong>Method:</strong> ${methodDisplay}</p>
            <p><strong>Date Rejected:</strong> ${formattedDate}</p>
            <p><strong>Reason for Rejection:</strong> ${reason || "Not specified"}</p>
          </div>
          
          <p>The funds have been returned to your available balance and you can submit a new withdrawal request.</p>
          <p>If you have any questions or need assistance, please contact our support team.</p>
          
          <p>Thank you for your understanding.</p>
          
          <p>Best regards,<br>
          Knowledge Hub Nepal Team</p>
        </div>
      </div>
    `
  }

  return sendEmail({
    to: email,
    subject,
    html: content,
  })
}

// Contact form email notification
export async function sendContactNotificationEmail({
  name,
  email,
  subject,
  message,
  priority,
}: {
  name: string
  email: string
  subject: string
  message: string
  priority: string
}) {
  const adminEmail = process.env.ADMIN_EMAIL || process.env.EMAIL_SERVER_USER

  if (!adminEmail) {
    console.log("Admin email not configured")
    return { success: false, error: "Admin email not configured" }
  }

  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>New Contact Form Submission</title>
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
        <h1 style="color: white; margin: 0; font-size: 24px;">New Contact Form Submission</h1>
      </div>
      
      <div style="background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px;">
        <div style="background: white; padding: 20px; border-radius: 5px; margin-bottom: 20px;">
          <h3 style="margin-top: 0; color: #333;">Contact Details</h3>
          <p><strong>Name:</strong> ${name}</p>
          <p><strong>Email:</strong> ${email}</p>
          <p><strong>Subject:</strong> ${subject}</p>
          <p><strong>Priority:</strong> <span style="background: ${priority === "urgent" ? "#ff4444" : priority === "high" ? "#ff8800" : priority === "medium" ? "#ffaa00" : "#00aa00"}; color: white; padding: 2px 8px; border-radius: 3px; font-size: 12px;">${priority.toUpperCase()}</span></p>
        </div>
        
        <div style="background: white; padding: 20px; border-radius: 5px;">
          <h3 style="margin-top: 0; color: #333;">Message</h3>
          <p style="white-space: pre-wrap;">${message}</p>
        </div>
        
        <p style="margin-top: 20px; font-size: 14px; color: #666;">
          You can reply to this message directly from your admin dashboard.
        </p>
      </div>
    </body>
    </html>
  `

  return sendEmail({
    to: adminEmail,
    subject: `New Contact: ${subject}`,
    html,
  })
}

// Contact form reply email
export async function sendContactReplyEmail({
  to,
  name,
  originalSubject,
  replyMessage,
}: {
  to: string
  name: string
  originalSubject: string
  replyMessage: string
}) {
  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Reply from Knowledge Hub Nepal</title>
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
        <h1 style="color: white; margin: 0; font-size: 24px;">Reply from Knowledge Hub Nepal</h1>
      </div>
      
      <div style="background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px;">
        <p>Hello ${name},</p>
        
        <p>Thank you for contacting Knowledge Hub Nepal. We have received your message regarding "<strong>${originalSubject}</strong>" and here is our response:</p>
        
        <div style="background: white; padding: 20px; border-radius: 5px; margin: 20px 0; border-left: 4px solid #667eea;">
          <p style="white-space: pre-wrap;">${replyMessage}</p>
        </div>
        
        <p>If you have any further questions, please don't hesitate to contact us again.</p>
        
        <p>Best regards,<br>
        Knowledge Hub Nepal Team</p>
      </div>
    </body>
    </html>
  `

  return sendEmail({
    to,
    subject: `Re: ${originalSubject}`,
    html,
  })
}
