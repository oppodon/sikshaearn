import { v2 as cloudinary } from "cloudinary"

// Configure Cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
})

/**
 * Upload a file to Cloudinary
 * @param buffer File buffer
 * @param folder Folder path
 * @param mimeType File MIME type
 * @returns Cloudinary upload result
 */
export async function uploadToCloudinary(buffer: ArrayBuffer, folder: string, mimeType: string) {
  // Convert buffer to base64
  const base64 = Buffer.from(buffer).toString("base64")
  const fileType = mimeType.split("/")[1]
  const dataURI = `data:${mimeType};base64,${base64}`

  // Upload to Cloudinary
  const result = await cloudinary.uploader.upload(dataURI, {
    folder,
    resource_type: "auto",
    format: fileType,
    transformation: [{ quality: "auto:good" }, { fetch_format: "auto" }],
  })

  return result
}

/**
 * Delete a file from Cloudinary
 * @param publicId Public ID of the file
 * @returns Cloudinary deletion result
 */
export async function deleteFromCloudinary(publicId: string) {
  const result = await cloudinary.uploader.destroy(publicId)
  return result
}
