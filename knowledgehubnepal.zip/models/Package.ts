import mongoose, { Schema, type Document } from "mongoose"

export interface IPackage extends Document {
  name: string
  title: string
  slug: string
  description: string
  price: number
  thumbnail: string
  isPopular: boolean
  courses: mongoose.Types.ObjectId[] | string[]
  createdAt: Date
  updatedAt: Date
}

const PackageSchema = new Schema(
  {
    name: {
      type: String,
      required: [true, "Package name is required"],
      trim: true,
    },
    title: {
      type: String,
      required: [true, "Package title is required"],
      trim: true,
    },
    slug: {
      type: String,
      required: [true, "Package slug is required"],
      unique: true,
      trim: true,
      lowercase: true,
    },
    description: {
      type: String,
      required: [true, "Package description is required"],
    },
    price: {
      type: Number,
      required: [true, "Package price is required"],
      min: 0,
    },
    thumbnail: {
      type: String,
      default: "",
    },
    isPopular: {
      type: Boolean,
      default: false,
    },
    courses: [
      {
        type: Schema.Types.ObjectId,
        ref: "Course",
      },
    ],
  },
  {
    timestamps: true,
  },
)

export default mongoose.models.Package || mongoose.model<IPackage>("Package", PackageSchema)
