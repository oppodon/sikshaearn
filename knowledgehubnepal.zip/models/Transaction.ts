import mongoose, { Schema, type Document } from "mongoose"

export interface ITransaction extends Document {
  user: mongoose.Types.ObjectId
  package: mongoose.Types.ObjectId
  amount: number
  paymentMethod: string
  paymentProof: string
  status: "pending" | "completed" | "rejected"
  rejectionReason?: string
  referredBy?: mongoose.Types.ObjectId
  commissionAmount: number
  createdAt: Date
  updatedAt: Date
}

const TransactionSchema = new Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: [true, "User is required"],
    },
    package: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Package",
      required: [true, "Package is required"],
    },
    amount: {
      type: Number,
      required: [true, "Amount is required"],
    },
    paymentMethod: {
      type: String,
      required: [true, "Payment method is required"],
      enum: ["bank_transfer", "esewa", "khalti", "fonepay"],
    },
    paymentProof: {
      type: String,
      required: [true, "Payment proof is required"],
    },
    status: {
      type: String,
      enum: ["pending", "completed", "rejected"],
      default: "pending",
    },
    rejectionReason: {
      type: String,
    },
    referredBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    commissionAmount: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
  },
)

export default mongoose.models.Transaction || mongoose.model<ITransaction>("Transaction", TransactionSchema)
