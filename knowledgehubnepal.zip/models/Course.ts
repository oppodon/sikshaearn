import mongoose, { Schema, type Document } from "mongoose"

export interface VideoLesson {
  title: string
  videoUrl: string
  duration: number
}

export interface ICourse extends Document {
  title: string
  slug: string
  description: string
  instructor: string
  thumbnail: string
  videoLessons: VideoLesson[]
  packages: mongoose.Types.ObjectId[]
  createdAt: Date
  updatedAt: Date
}

const VideoLessonSchema = new Schema({
  title: { type: String, required: true },
  videoUrl: { type: String, required: true },
  duration: { type: Number, required: true },
})

const CourseSchema = new Schema(
  {
    title: {
      type: String,
      required: true,
    },
    slug: {
      type: String,
      required: true,
      unique: true,
    },
    description: {
      type: String,
      required: true,
    },
    instructor: {
      type: String,
      required: true,
    },
    thumbnail: {
      type: String,
      default: "/placeholder.svg?height=200&width=300",
    },
    videoLessons: [VideoLessonSchema],
    packages: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Package",
      },
    ],
  },
  { timestamps: true },
)

// Create slug from title before saving
CourseSchema.pre("save", function (next) {
  if (this.isModified("title")) {
    this.slug = this.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "")
  }
  next()
})

// Check if the model already exists to prevent overwriting during hot reloads
const Course = mongoose.models.Course || mongoose.model<ICourse>("Course", CourseSchema)

export default Course
